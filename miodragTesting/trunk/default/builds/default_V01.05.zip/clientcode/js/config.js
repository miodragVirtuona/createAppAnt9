var APP = {
	FU_URI: "",
	EXISTING_LANGUAGES : ["en"],
	LANGUAGE_RESOURCES: {
		"en": "http://localhost/virtdev_scas/resources/TasorProjects/miodragTestingAppType_wds/en.json"
	},
	DEFAULT_LANGUAGE : "en",
	APP_TYPE_PROJ : "http://localhost/virtdev_scas/resources/TasorProjects/miodragTestingAppType",
	APP_KB_PROJ : "http://localhost/virtdev_scas/resources/TasorProjects/miodragTestingAppKB",
	APP_ONTOS_PROJ : "http://localhost/virtdev_scas/resources/TasorProjects/miodragTestingAppOntos",
	APP_KB_WDS: "http://localhost/virtdev_scas/resources/TasorProjects/miodragTestingAppKB_WDS",
    APP_KB_DELETE_DS: "http://localhost/virtdev_scas/resources/TasorProjects/miodragTestingAppKB_WDS_deletedResources",
	EXT_LINKS : {},
};
